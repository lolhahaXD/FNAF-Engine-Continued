when player KeyCode.Mouse0 on ID("Pull")
   gotomenu on Order("2,3,4")
     each time ID("pull")
end)