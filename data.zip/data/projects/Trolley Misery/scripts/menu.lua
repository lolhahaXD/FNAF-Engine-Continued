when player KeyCode.Mouse0 on id("p")
   gotomenu("Prob1")
end)

when player KeyCode.Mouse0 on id("q")
   quit game
end)